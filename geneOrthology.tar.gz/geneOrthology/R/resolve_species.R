resolve_species <- function(x) {
  x <- tolower(x)
  hit <- species_table[species_table$name == x | species_table$org == x | species_table$db == x, ]
  if (nrow(hit) == 0) stop("Unknown species: ", x)
  return(hit)
}
